package com.example.miprimerprograma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.TextViewCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    /*Button boton1;
    Button boton2;
    EditText numero1;
    EditText numero2;
    EditText respuesta;*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*numero1 = (EditText) findViewById(R.id.numero1);
        numero2 = (EditText) findViewById(R.id.numero2);
        respuesta = (EditText) findViewById(R.id.respuesta);*/
/*
        boton1 = (Button) findViewById(R.id.boton1);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());

                int suma = num1 + num2;
                respuesta.setText(String.valueOf(suma));
                //Toast.makeText(getApplicationContext(),"oprimio el boton 1", Toast.LENGTH_LONG).show();
            }
        });*/

        /*boton2 = (Button) findViewById(R.id.boton2);
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent segundaPantalla = new Intent(getApplicationContext(),MainActivity2.class);
                startActivity(segundaPantalla);

            }
        });*/


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater infalter = getMenuInflater();
        infalter.inflate(R.menu.menuopciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if(id == R.id.opcion1){
            Intent segundaPantalla = new Intent(getApplicationContext(),MainActivity2.class);
            startActivity(segundaPantalla);
        }
        if(id == R.id.opcion2){
            Intent terceraPantalla = new Intent(getApplicationContext(),MainActivity3.class);
            startActivity(terceraPantalla);
        }
        if(id == R.id.opcion3){
            Intent cuartaPantalla = new Intent(getApplicationContext(),MainActivity4.class);
            startActivity(cuartaPantalla);
        }
        return super.onOptionsItemSelected(item);
    }
}