package com.example.miprimerprograma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {

    Drawable drawable6, drawable7,drawable8;
    ImageView imagen6, imagen7,imagen8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);


        Resources res = getResources();
        drawable6 = res.getDrawable(R.drawable.tienda1,getTheme());

        imagen6 = (ImageView) findViewById(R.id.imageView);
        imagen6.setImageDrawable(drawable6);
        //------------------------------------------------------------
        Resources res2 = getResources();
        drawable7 = res2.getDrawable(R.drawable.tienda2,getTheme());

        imagen7 = (ImageView) findViewById(R.id.imageView2);
        imagen7.setImageDrawable(drawable7);
        //------------------------------------------------------------
        Resources res3 = getResources();
        drawable8 = res3.getDrawable(R.drawable.tienda3,getTheme());

        imagen8 = (ImageView) findViewById(R.id.imageView3);
        imagen8.setImageDrawable(drawable8);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater infalter = getMenuInflater();
        infalter.inflate(R.menu.menuopciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if(id == R.id.opcion1){
            Intent segundaPantalla = new Intent(getApplicationContext(),MainActivity2.class);
            startActivity(segundaPantalla);
            Toast.makeText(this,"Oprimió la opción Productos", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.opcion2){
            Intent terceraPantalla = new Intent(getApplicationContext(),MainActivity3.class);
            startActivity(terceraPantalla);
            Toast.makeText(this,"Oprimió la opción Servicios", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.opcion3){
            Intent cuartaPantalla = new Intent(getApplicationContext(),MainActivity4.class);
            startActivity(cuartaPantalla);
            Toast.makeText(this,"Oprimió la opción Sucursales", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}