package com.example.miprimerprograma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;


public class MainActivity2 extends AppCompatActivity {


    Drawable drawable1,drawable2,drawable3;
    ImageView imagen1,imagen2,imagen3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        Resources res = getResources();
        drawable1 = res.getDrawable(R.drawable.chaqueta1,getTheme());

        imagen1 = (ImageView) findViewById(R.id.imagen1);
        imagen1.setImageDrawable(drawable1);
        //------------------------------------------------------------
        Resources res2 = getResources();
        drawable2 = res2.getDrawable(R.drawable.chaqueta2,getTheme());

        imagen2 = (ImageView) findViewById(R.id.imagen2);
        imagen2.setImageDrawable(drawable2);
        //------------------------------------------------------------
        Resources res3 = getResources();
        drawable3 = res3.getDrawable(R.drawable.chaqueta3,getTheme());

        imagen3 = (ImageView) findViewById(R.id.imagen3);
        imagen3.setImageDrawable(drawable3);


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater infalter = getMenuInflater();
        infalter.inflate(R.menu.menuopciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if(id == R.id.opcion1){
            Intent segundaPantalla = new Intent(getApplicationContext(),MainActivity2.class);
            startActivity(segundaPantalla);
            Toast.makeText(this,"Oprimió la opción Productos", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.opcion2){
            Intent terceraPantalla = new Intent(getApplicationContext(),MainActivity3.class);
            startActivity(terceraPantalla);
            Toast.makeText(this,"Oprimió la opción Servicios", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.opcion3){
            Intent cuartaPantalla = new Intent(getApplicationContext(),MainActivity4.class);
            startActivity(cuartaPantalla);
            Toast.makeText(this,"Oprimió la opción Sucursales", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}