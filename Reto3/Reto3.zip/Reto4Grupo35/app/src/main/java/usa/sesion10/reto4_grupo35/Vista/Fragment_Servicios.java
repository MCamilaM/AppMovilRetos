package usa.sesion10.reto4_grupo35.Vista;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

import usa.sesion10.reto4_grupo35.Modelo.Adaptador;
import usa.sesion10.reto4_grupo35.Modelo.BaseDatos.MotorBaseDatosSQLite;
import usa.sesion10.reto4_grupo35.Modelo.Entidad;
import usa.sesion10.reto4_grupo35.R;


public class Fragment_Servicios extends Fragment {

    String TAG = "Fragment_Servicios";

    int [] imagen = {R.drawable.servicio1, R.drawable.servicio2 };

    View v;

    ListView listaServicios;
    Adaptador adaptador;

    // CONEXION A LA BASE DE DATOS: SQLite


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__servicios, container, false);
        //-----------------------------------------------------------------------------
        listaServicios = (ListView) v.findViewById(R.id.lista_servicios);
        adaptador = new Adaptador(getTablaServicios(), getContext());

        listaServicios.setAdapter(adaptador);

        //-----------------------------------------------------------------------------
        return v;
    }

    private ArrayList<Entidad> getTablaServicios(){
        ArrayList<Entidad> listaServicios = new ArrayList<>();

        MotorBaseDatosSQLite conectar = new MotorBaseDatosSQLite(getContext(),"TiendaProductos", null, 1);

        SQLiteDatabase db_leer = conectar.getReadableDatabase();
        //conectar.onUpgrade(db_leer,1,2);
        Cursor cursor = db_leer.rawQuery("SELECT * FROM servicios", null);

        while(cursor.moveToNext()){

           // listaServicios.add(new Entidad(imagen[cursor.getInt(0)], cursor.getString(1), cursor.getString(2)));
            listaServicios.add(new Entidad(cursor.getString(0), imagen[cursor.getInt(1)], cursor.getString(2), cursor.getString(3)));
            //listaServicios.add(new Entidad(cursor.getString(0), 0, cursor.getString(2), cursor.getString(3)));

        }


        return listaServicios;
    }

    private ArrayList<Entidad> getArrayItems(){
        ArrayList<Entidad> listaItems = new ArrayList<Entidad>();
        listaItems.add(new Entidad("SR01",R.drawable.servicio1, "24/7", "siempre contigo"));
        listaItems.add(new Entidad("SR02",R.drawable.servicio2, "Domicilios", "Envios a todo el pais"));
        return listaItems;
    }
}