package usa.sesion10.reto4_grupo35.Vista;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

import usa.sesion10.reto4_grupo35.Modelo.Adaptador;
import usa.sesion10.reto4_grupo35.Modelo.BaseDatos.MotorBaseDatosSQLite;
import usa.sesion10.reto4_grupo35.Modelo.Entidad;
import usa.sesion10.reto4_grupo35.R;


public class Fragment_Productos extends Fragment {

    int [] imagen = {R.drawable.chaqueta1, R.drawable.chaqueta2, R.drawable.chaqueta3 };

    String TAG = "Fragment_Productos";

    View v;

    ListView listaViewProductos;
    Adaptador adaptador;

    Cursor cursor;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__productos, container, false);
        //-----------------------------------------------------------------------------
        listaViewProductos = (ListView) v.findViewById(R.id.lista_productos);
        adaptador = new Adaptador(getTablaProductos(), getContext());

        listaViewProductos.setAdapter(adaptador);

        return v;
    }

    private ArrayList<Entidad> getTablaProductos(){
        ArrayList<Entidad> listaProductos = new ArrayList<>();
        MotorBaseDatosSQLite conectar = new MotorBaseDatosSQLite(getContext(),"TiendaProductos", null, 1);

        SQLiteDatabase db_leer = conectar.getReadableDatabase();

        //conectar.onUpgrade(db_leer,1,2);
        cursor = db_leer.rawQuery("SELECT * FROM productos", null);


        while(cursor.moveToNext()){

            listaProductos.add(new Entidad(cursor.getString(0), imagen[cursor.getInt(1)], cursor.getString(2), cursor.getString(3)));

        }


        return listaProductos;
    }

    private ArrayList<Entidad> getListItems(){
        ArrayList<Entidad> listaItems = new ArrayList<>();
        listaItems.add(new Entidad("CHH01",R.drawable.chaqueta1, "Chaqueta Hombre Casual", "Precio: $127.432"));
        listaItems.add(new Entidad("CHH02",R.drawable.chaqueta2, "Chaqueta Hombre University Club", "Precio: $142.324"));
        listaItems.add(new Entidad("CHH03",R.drawable.chaqueta3, "Chaqueta Hombre Finland Roly", "Precio: $99.999"));
        return listaItems;

    }
}